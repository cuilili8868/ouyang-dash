# -*- coding: utf-8 -*-
import mysql.connector
import matplotlib.pyplot as plt
import os
import re

#this function return a list contain all the .log files's name in work_path
def find_logfiles_in_workpath(work_path_name):
    log_file_names = [os.path.join(dp, f) for dp, dn, filenames in\
        os.walk(work_path) for f in filenames \
        if os.path.splitext(f)[1] == '.log']
    return log_file_names


#this function returns sql items from a set of files relate to .log file #each item contains [time, mtune_label, bench_mark, type, base_time, base_rate,
#                    cpu, os, kernal_version, gcc_version]
#for example, an item is like this
#[2019-03-22, mtune_generic_o2, 500.perlbench_r, SPECrate2017_int, 356, 4.47
#       AMD Ryzen 7 2700X Eight-Core, Red Hat Enterprise Linux Server release 7.6
#       3.10.0-957.el7.x86_64, 3.10.0-957.el7.x86_64]
def get_sql_items(log_file_name):
    subs_info = []#subfile info relate to the .log file
    sql_items = []
    log_file = open(log_file_name)
    #get time
    line = log_file.readline()
    env_time = re.search(r"(\d*\-\d*\-\d*)", line).group(1)
    #get mtune label
    line = log_file.readline()
    line = log_file.readline()
    env_mtune = re.search(r"--label (\w*)", line).group(1)
    #get subfile info
    while(1):
        line = log_file.readline()
        if (line[0:5] == "-----"):
            while(1):
                line = log_file.readline()
                if line[0:5] == "-----":
                    break
                line = re.split(r' +',line)[3:5]
                subs_info.append(line)
            break
    for sub_info in subs_info:
        try:
            sub_file_name = log_file_name[:-3] + sub_info[1] + '.refrate.txt'
            sub_file = open(sub_file_name)
        except IOError:
            print("Warning: Can not open "+sub_file_name)
            continue
        #get bench_mark, type, base_time, base_rate
        while(1):
            line = sub_file.readline()
            if line[0:5] == "-----":
                while(1):
                    line = sub_file.readline()
                    if line[0:5] == "=====":
                        break
                    info = re.split(r' +',line)
                    bench_mark = info[0]
                    spec_type = sub_info[0]
                    base_time = info[2]
                    base_rate = info[3]
                    sql_items.append([bench_mark, spec_type , base_time, base_rate])
                break
        #for item in sql_items:
        #    print(item)
        while(1):#get cpu name
            line = sub_file.readline()
            match_object = re.search(r"CPU Name: (.*)", line)
            if match_object is not None:
                env_cpu = match_object.group(1)
                break
        while(1):#get OS name and kernal version
            line = sub_file.readline()
            match_object = re.search(r"OS: (.*)", line)
            if match_object is not None:
                env_os = match_object.group(1)
                while(1):
                    line = sub_file.readline()
                    match_object = re.search(r" *(.*)", line)
                    if match_object.group(1)[0] != "(":
                        env_kernal = match_object.group(1)
                        break
                break
        while(1):#get gcc version
            line = sub_file.readline()
            match_object = re.search(r"gcc version (\S*) ", line)
            if match_object is not None:
                env_gcc = match_object.group(1)
                break
    env_info = [env_time, env_mtune, env_cpu, env_os, env_kernal, env_gcc]
    for i in range(len(sql_items)):
        sql_items[i] = env_info[:2] + sql_items[i] + env_info[2:]
    return sql_items

work_path = "/home/ouyangch/spec/test/"
database = []
groups = []
log_file_names = find_logfiles_in_workpath(work_path)
for log_file_name in log_file_names:
    database += get_sql_items(log_file_name)
for i in range(len(database[0])):
    groups.append([])
for item in database:
   for i in range(len(item)):
       if item[i] not in groups[i]:
           groups[i].append(item[i])
print(len(database))


#[0:2019-03-22, 1:mtune_generic_o2, 2:500.perlbench_r, 3:SPECrate2017_int, 4:356, 5:4.47
#       6:AMD Ryzen 7 2700X Eight-Core, 7:Red Hat Enterprise Linux Server release 7.6
#       8:3.10.0-957.el7.x86_64, 9:9.0.1]
def get_compare_pairs(group_ID, name):
    bench_marks_for_this_group = [[0 for x in range(len(groups[group_ID]))] for y in range(len(groups[2]))]
    bench_marks_for_this_group_count = [[0 for x in range(len(groups[group_ID]))] for y in range(len(groups[2]))]
    for item in database:
        for i,group_name in enumerate(groups[group_ID]):
            for j,bench_mark in enumerate(groups[2]):
                if item[group_ID] == group_name:
                    if item[2] == bench_mark:
                        try:
                            bench_marks_for_this_group[j][i] += float(item[5])
                        except:
                            continue
                        bench_marks_for_this_group_count[j][i] += 1
    for item in groups[group_ID]:
        print(item)
    group_members_compare = [[] for x in range(len(groups[group_ID]))]
    for i in range(len(groups[2])):
        for j in range(len(groups[group_ID])):
            if bench_marks_for_this_group_count[i][j]==0:
                continue
            group_members_compare[j].append(bench_marks_for_this_group[i][j]/bench_marks_for_this_group_count[i][j])

    figure_data_structure={
    'data':
      [{'x': groups[2], 'y': group_members_compare[i], 'type': 'bar', 'name': groups[group_ID][i]} \
                for i in range(len(group_members_compare))],
    'layout':
      {'title': name}
    }

    return figure_data_structure



#gcc_compare = get_compare_pairs(9)
#mtune_compare = get_compare_pairs(1)


import dash
import dash_core_components as dcc
import dash_html_components as html

#kexternal_stylesheets = ['https://codepen.io/chriddyp/pen/bWLwgP.css']
external_stylesheets = ['template.css']

app = dash.Dash(__name__, external_stylesheets=external_stylesheets)
app.css.config.serve_locally = True
app.scripts.config.serve_locally = True
app.layout = html.Div(children=[
    html.H1(children='GCC SPEC'),
    html.Div(children=' A web application for GCC-SPEC based on Dash framework.'),
    dcc.Graph(id='AMD vs INTEL', figure=get_compare_pairs(6, 'AMD vs INTEL')),
    dcc.Graph(id='GCC version',  figure=get_compare_pairs(9, 'GCC version')),
    dcc.Graph(id='mtune',        figure=get_compare_pairs(1, 'mtune'))


])

if __name__ == '__main__':
    app.run_server(debug=False, port=8080, host="0.0.0.0") 
